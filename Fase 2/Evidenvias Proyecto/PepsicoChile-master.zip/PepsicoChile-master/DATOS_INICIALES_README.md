# ?? BASE DE DATOS INICIALIZADA CORRECTAMENTE

## ? RESUMEN DE DATOS

### ?? Estad�sticas:
- **Base de Datos**: `pepsico_taller`
- **Usuarios**: 16
- **Veh�culos**: 12
- **Tablas**: 10
- **Password universal**: `123456` (Hash: `jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=`)

---

## ?? USUARIOS Y CREDENCIALES

### ?? Todos los usuarios tienen password: **123456**

| # | Nombre Completo | Email | Rol | Tel�fono |
|---|----------------|-------|-----|----------|
| 1 | **Administrador Sistema** | admin@pepsico.cl | Administrador | +56912345678 |
| 2 | Mar�a L�pez | supervisor@pepsico.cl | Supervisor | +56912345679 |
| 3 | Pedro Morales | jefetaller@pepsico.cl | JefeTaller | +56912345680 |
| 4 | Ana Torres | coordinador@pepsico.cl | CoordinadorZona | +56912345681 |
| 5 | Carlos Rojas | carlos.rojas@pepsico.cl | Mecanico | +56912345682 |
| 6 | Luis Mu�oz | luis.munoz@pepsico.cl | Mecanico | +56912345683 |
| 7 | Roberto Silva | roberto.silva@pepsico.cl | Mecanico | +56912345684 |
| 8 | Diego Vargas | diego.vargas@pepsico.cl | Mecanico | +56912345685 |
| 9 | Juan P�rez | juan.perez@pepsico.cl | Chofer | +56912345686 |
| 10 | Pedro Gonz�lez | pedro.gonzalez@pepsico.cl | Chofer | +56912345687 |
| 11 | Jorge Ram�rez | jorge.ramirez@pepsico.cl | Chofer | +56912345688 |
| 12 | Andr�s Castro | andres.castro@pepsico.cl | Chofer | +56912345689 |
| 13 | Mar�a Fern�ndez | recepcionista@pepsico.cl | Recepcionista | +56912345690 |
| 14 | Luis Soto | guardia@pepsico.cl | GuardiaAcceso | +56912345691 |
| 15 | Carmen Bravo | repuestos@pepsico.cl | AsistenteRepuestos | +56912345692 |
| 16 | Ricardo Vega | llaves@pepsico.cl | EncargadoLlaves | +56912345693 |

---

## ?? VEH�CULOS

### Camiones (5):
| Patente | Marca | Modelo | Flota | Kilometraje |
|---------|-------|--------|-------|-------------|
| ABCD-12 | Volvo | FH16 | FL-001 | 45,000 km |
| EFGH-34 | Mercedes-Benz | Actros | FL-002 | 52,000 km |
| IJKL-56 | Scania | R450 | FL-003 | 38,000 km |
| MNOP-78 | Volvo | FM12 | FL-004 | 68,000 km |
| QRST-90 | Freightliner | Cascadia | FL-005 | 41,000 km |

### Camionetas (3):
| Patente | Marca | Modelo | Flota | Kilometraje |
|---------|-------|--------|-------|-------------|
| UVWX-11 | Ford | Ranger | CM-001 | 15,000 km |
| YZAB-22 | Toyota | Hilux | CM-002 | 22,000 km |
| CDEF-33 | Chevrolet | Colorado | CM-003 | 28,000 km |

### Vans (4):
| Patente | Marca | Modelo | Flota | Kilometraje |
|---------|-------|--------|-------|-------------|
| GHIJ-44 | Nissan | NP300 | SV-001 | 35,000 km |
| KLTF-35 | Mercedes-Benz | Sprinter | SV-002 | 18,000 km |
| MNOP-55 | Ford | Transit | EM-001 | 12,000 km |
| QRST-66 | Iveco | Daily | EM-002 | 25,000 km |

---

## ?? C�MO USAR EL SISTEMA

### 1. Iniciar la Aplicaci�n:
```bash
# En Visual Studio
Presiona F5
```

### 2. Acceder al Login:
```
URL: http://localhost:XXXX/Account/Login
```

### 3. Credenciales de Acceso:

#### **????? Administrador (Acceso Total):**
```
Email: admin@pepsico.cl
Password: 123456
```

#### **?? Supervisor (Gesti�n de Taller):**
```
Email: supervisor@pepsico.cl
Password: 123456
```

#### **?? Mec�nico (Tareas):**
```
Email: carlos.rojas@pepsico.cl
Password: 123456
```

#### **?? Chofer (Ingresos):**
```
Email: juan.perez@pepsico.cl
Password: 123456
```

---

## ?? FLUJO DE PRUEBA COMPLETO

### Escenario: Programar Mantenimiento y Asignar Tarea

```
1?? LOGIN COMO SUPERVISOR
   Email: supervisor@pepsico.cl
   Password: 123456

2?? PROGRAMAR INGRESO
   ? Click en "Programar Ingreso"
   ? Veh�culo: ABCD-12 (Volvo FH16)
   ? Chofer: Juan P�rez
   ? Mec�nico: Carlos Rojas
   ? Motivo: "Mantenimiento 50,000 km"
   ? Click en "Programar"

3?? GESTIONAR INGRESO
   ? Ve a "Agenda"
   ? Click en el ingreso reci�n creado
   ? Click en "Iniciar Ingreso"

4?? ASIGNAR TAREA
   ? Descripci�n: "Cambio de aceite y filtros"
   ? Mec�nico: Carlos Rojas
   ? Prioridad: Alta
   ? Click en "Asignar Tarea"
   
   ? El mec�nico recibe:
      - Notificaci�n web (campana ??)
      - WhatsApp (si est� configurado Twilio)

5?? LOGIN COMO MEC�NICO
   Email: carlos.rojas@pepsico.cl
   Password: 123456
   
   ? Ve a "Tareas Asignadas"
   ? Ver�s la tarea asignada
   ? Click en la tarea
   ? Marca como "En Proceso"
   ? Agrega observaciones
   ? Marca como "Completada"

6?? FINALIZAR INGRESO (Como Supervisor)
   ? Vuelve a la gesti�n del ingreso
   ? Click en "Finalizar Ingreso"
   ? El veh�culo vuelve a estado "Disponible"
```

---

## ?? NOTIFICACIONES WHATSAPP

### Configuraci�n Actual:
```json
"Twilio": {
  "AccountSid": "TU_ACCOUNT_SID",
  "AuthToken": "TU_AUTH_TOKEN",
  "WhatsAppNumber": "+19896933171"
}
```

### Para Activar WhatsApp:
1. Configura User Secrets con credenciales reales
2. Los n�meros de tel�fono est�n en formato: `+56912345XXX`
3. WhatsApp se env�a cuando:
   - Prioridad Alta ? Tipo: "Urgente"
   - Prioridad Media/Baja ? Tipo: "Tarea"

---

## ?? COMANDOS �TILES

### Ver todos los usuarios:
```sql
SELECT Id, Nombre + ' ' + Apellido AS Nombre, Email, Rol 
FROM Usuarios 
ORDER BY Rol, Nombre;
```

### Ver todos los veh�culos:
```sql
SELECT Patente, Marca, Modelo, Estado, KilometrajeActual 
FROM Vehiculos 
ORDER BY TipoVehiculo, Patente;
```

### Ver notificaciones:
```sql
SELECT u.Nombre, n.Titulo, n.Tipo, n.EnviadoWhatsApp 
FROM Notificaciones n
INNER JOIN Usuarios u ON n.UsuarioId = u.Id
ORDER BY n.FechaCreacion DESC;
```

---

## ? VERIFICACI�N

Para verificar que todo funciona:

1. ? Base de datos creada
2. ? 16 usuarios insertados
3. ? 12 veh�culos insertados
4. ? Todas las tablas creadas (incluida Notificaciones)
5. ? Todos con password `123456`
6. ? User Secrets configurado para Twilio
7. ? Sistema listo para usar

---

## ?? �SISTEMA LISTO PARA USAR!

```
?? Login: admin@pepsico.cl / 123456
?? WhatsApp: Configurado (requiere credenciales reales)
??? Base de datos: PepsicoChileDB
?? Usuarios: 16 (todos con password: 123456)
?? Veh�culos: 12 
?? Todo funcional
```

**�Buen trabajo! ??**

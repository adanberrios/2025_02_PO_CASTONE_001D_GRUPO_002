# PepsiCo Chile - Sistema de Gesti�n de Taller ??

Sistema web para gestionar el ingreso y mantenimiento de veh�culos de la flota de PepsiCo Chile.

## ?? Caracter�sticas

- ? **Sistema de Login** con autenticaci�n y sesiones
- ? **3 Roles de Usuario**: Chofer, Supervisor y Mec�nico
- ? **Dashboard** personalizado seg�n rol
- ? **Gesti�n de Ingresos** de veh�culos al taller
- ? **Asignaci�n de Tareas** a mec�nicos
- ? **Control de Pausas** en los procesos
- ? **Subida de Documentos** y fotograf�as
- ? **Reportes** de tiempos, productividad y repuestos
- ? **Historial de Veh�culos** y trazabilidad completa

## ?? Tecnolog�as Utilizadas

- **Backend**: ASP.NET Core 8.0 MVC
- **Base de Datos**: SQL Server Express
- **ORM**: Entity Framework Core 9.0
- **Frontend**: Bootstrap 5, Bootstrap Icons
- **Autenticaci�n**: Sesiones + Hash SHA256

## ?? Requisitos Previos

- .NET 8.0 SDK
- SQL Server Express (instancia `TICA\SQLEXPRESS`)
- Visual Studio 2022 o VS Code

## ?? Instalaci�n y Configuraci�n

### 1. Clonar o abrir el proyecto

```bash
cd C:\Users\insec\source\repos\PepsicoChile\PepsicoChile
```

### 2. Restaurar paquetes NuGet

```bash
dotnet restore
```

### 3. Configurar la Base de Datos

La cadena de conexi�n ya est� configurada en `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=TICA\\\\SQLEXPRESS;Database=pepsico_taller;Integrated Security=True;TrustServerCertificate=True;MultipleActiveResultSets=true;Encrypt=False"
  }
}
```

### 4. Ejecutar el Script SQL

El script `Database/CreateTables.sql` ya fue ejecutado y cre�:
- ? Base de datos `pepsico_taller`
- ? Todas las tablas necesarias
- ? 5 usuarios de prueba

### 5. Ejecutar la Aplicaci�n

```bash
dotnet run
```

O presiona **F5** en Visual Studio.

La aplicaci�n estar� disponible en: `https://localhost:XXXX`

## ?? Usuarios de Prueba

Todos los usuarios tienen la contrase�a: **123456**

| Email | Rol | Descripci�n |
|-------|-----|-------------|
| `supervisor@pepsico.cl` | Supervisor | Gestiona ingresos y asigna tareas |
| `juan.perez@pepsico.cl` | Chofer | Registra llegadas de veh�culos |
| `pedro.gonzalez@pepsico.cl` | Chofer | Registra llegadas de veh�culos |
| `carlos.rojas@pepsico.cl` | Mec�nico | Ejecuta tareas de taller |
| `luis.munoz@pepsico.cl` | Mec�nico | Ejecuta tareas de taller |

## ?? Funcionalidades por Rol

### ???? Chofer
- Registrar llegada de veh�culos
- Ver mis ingresos hist�ricos
- Consultar estado de veh�culos

### ??? Guardia de Acceso
- Registrar llegadas de veh�culos al taller
- Ver veh�culos programados del d�a
- Consultar agenda de ingresos
- Historial de llegadas
- Estad�sticas por turno (ma�ana/tarde/noche)
- Control de acceso vehicular

### ???? Supervisor
- Programar ingresos al taller
- Gestionar agenda de ingresos
- Asignar tareas a mec�nicos
- Registrar pausas en procesos
- Ver monitoreo general
- Generar reportes

### ???? Mec�nico
- Ver mis tareas asignadas
- Iniciar y finalizar tareas
- Subir documentos y fotograf�as
- Solicitar repuestos
- Agregar observaciones

### ?? Asistente de Repuestos
- Gestionar solicitudes de repuestos
- Control de inventario
- Registrar movimientos de stock
- Ver repuestos cr�ticos
- Gestionar proveedores

## ?? Estructura del Proyecto

```
PepsicoChile/
??? Controllers/           # Controladores MVC
?   ??? AccountController.cs
?   ??? HomeController.cs
?   ??? ChoferController.cs
?   ??? SupervisorController.cs
?   ??? MecanicoController.cs
?   ??? VehiculosController.cs
?   ??? ReportesController.cs
??? Models/  # Modelos de datos
?   ??? Usuario.cs
?   ??? Vehiculo.cs
?   ??? IngresoTaller.cs
?   ??? TareaTaller.cs
?   ??? Pausa.cs
?   ??? Documento.cs
?   ??? Repuesto.cs
?   ??? ViewModels/      # ViewModels
??? Views/               # Vistas Razor
?   ??? Account/
?   ??? Home/
?   ??? Chofer/
?   ??? Supervisor/
?   ??? Mecanico/
?   ??? Vehiculos/
?   ??? Reportes/
??? Data/      # DbContext
?   ??? ApplicationDbContext.cs
??? Filters/ # Filtros de autorizaci�n
?   ??? AuthorizeSessionAttribute.cs
??? Database/   # Scripts SQL
    ??? CreateTables.sql
```

## ?? Seguridad

- Las contrase�as se almacenan hasheadas con SHA256
- Sistema de sesiones para mantener autenticaci�n
- Filtros de autorizaci�n por rol
- Validaci�n de permisos en cada acci�n

## ?? Base de Datos

### Tablas Principales

1. **Usuarios** - Informaci�n de usuarios y credenciales
2. **Vehiculos** - Flota de veh�culos
3. **IngresosTaller** - Registros de ingresos al taller
4. **TareasTaller** - Tareas asignadas
5. **Pausas** - Pausas en los procesos
6. **Documentos** - Archivos y fotograf�as
7. **Repuestos** - Control de repuestos solicitados

## ?? Interfaz de Usuario

- **Dise�o Responsivo** con Bootstrap 5
- **Iconos** de Bootstrap Icons
- **Colores**: Paleta corporativa de PepsiCo (azul #004B8D)
- **Navegaci�n** adaptada seg�n rol del usuario

## ?? Pr�ximas Mejoras

- [ ] Implementaci�n real de base de datos en controladores
- [ ] Integraci�n con sistema ERP
- [ ] M�dulo financiero de costos
- [ ] Aplicaci�n m�vil nativa
- [ ] Notificaciones push
- [ ] Reportes en PDF
- [ ] Dashboard con gr�ficos interactivos

## ?? Soporte

Para consultas o problemas, contactar al equipo de desarrollo.

## ?? Licencia

� 2025 PepsiCo Chile. Todos los derechos reservados.

# ?? Fix de Hash de Contrase�a - PepsiCo Chile

## ? Problema Resuelto

El hash de la contrase�a "123456" estaba incorrecto en la base de datos.

### Hash Incorrecto (anterior):
```
jGl25bVBBBW96Qi9Te4V37Fnqchz/Eu4qB9vKrRIqRg=
```

### Hash Correcto (actual):
```
jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=
```

## ?? Cambios Realizados

### 1. Script SQL Actualizado
- ? `Database/CreateTables.sql` - Hash corregido
- ? `Database/UpdatePasswords.sql` - Script nuevo para actualizar contrase�as

### 2. Contrase�as en BD Actualizadas
```sql
-- Se ejecut� exitosamente:
UPDATE Usuarios SET Password = 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI='
-- (5 rows affected)
```

### 3. Controller Mejorado
- ? Mejor manejo de errores en `Login()`
- ? Endpoints de diagn�stico agregados:
  - `/Account/TestHash?password=123456` - Verifica hash
  - `/Account/TestUsers` - Lista usuarios y sus hashes

## ?? Testing

### 1. Detener y Reiniciar la Aplicaci�n
```bash
# Presiona Shift + F5 para detener
# Presiona F5 para iniciar de nuevo
```

### 2. Probar Login
Usa cualquiera de estos usuarios con contrase�a **123456**:

| Email | Contrase�a | Rol |
|-------|-----------|-----|
| supervisor@pepsico.cl | 123456 | Supervisor |
| juan.perez@pepsico.cl | 123456 | Chofer |
| carlos.rojas@pepsico.cl | 123456 | Mec�nico |

### 3. Verificar Hash (Desarrollo)
Abre en el navegador:
```
https://localhost:XXXX/Account/TestHash?password=123456
```

Deber�as ver:
```json
{
  "password": "123456",
  "generatedHash": "jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=",
  "expectedHash": "jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=",
  "match": true,
  "message": "? Hash correcto"
}
```

### 4. Verificar Usuarios en BD (Desarrollo)
```
https://localhost:XXXX/Account/TestUsers
```

## ?? Seguridad

### ?? IMPORTANTE - Antes de Producci�n:

**ELIMINAR** los siguientes endpoints de diagn�stico en `AccountController.cs`:
- `TestHash()` - L�nea ~95
- `TestUsers()` - L�nea ~108

Estos endpoints son **SOLO PARA DESARROLLO** y exponen informaci�n sensible.

## ?? Verificaci�n del Hash SHA256

### Algoritmo Usado:
```csharp
using (var sha256 = SHA256.Create())
{
    var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
    return Convert.ToBase64String(hashedBytes);
}
```

### Verificaci�n en PowerShell:
```powershell
$password = "123456"
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$bytes = [System.Text.Encoding]::UTF8.GetBytes($password)
$hash = $sha256.ComputeHash($bytes)
[Convert]::ToBase64String($hash)
# Output: jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=
```

## ? Checklist Post-Fix

- [x] Hash corregido en `CreateTables.sql`
- [x] Script `UpdatePasswords.sql` creado
- [x] Contrase�as actualizadas en BD (5 usuarios)
- [x] Endpoints de diagn�stico agregados
- [x] Mejor manejo de errores en Login
- [ ] Reiniciar aplicaci�n
- [ ] Probar login con todos los usuarios
- [ ] Verificar hash con endpoint `/TestHash`
- [ ] **ANTES DE PRODUCCI�N**: Eliminar endpoints de test

## ?? Resultado Esperado

Despu�s de estos cambios, deber�as poder:
1. ? Iniciar sesi�n con **123456** como contrase�a
2. ? Ver tu nombre y rol en el navbar
3. ? Acceder al dashboard seg�n tu rol
4. ? Cerrar sesi�n correctamente

## ?? Si Contin�a el Problema

1. Verifica la cadena de conexi�n en `appsettings.json`
2. Confirma que el script SQL se ejecut�: `(5 rows affected)`
3. Usa el endpoint `/Account/TestUsers` para verificar los hashes en BD
4. Revisa los logs de la aplicaci�n para errores espec�ficos

---

**�ltima actualizaci�n:** $(Get-Date)
**Hash verificado con:** SHA256 en .NET 8

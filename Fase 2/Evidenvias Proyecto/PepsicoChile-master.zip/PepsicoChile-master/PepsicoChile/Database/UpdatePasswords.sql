-- Script para actualizar las contrase�as de los usuarios existentes
-- PepsiCo Chile - Sistema de Gesti�n de Taller

USE pepsico_taller;
GO

-- Password hash correcto de "123456" usando SHA256
DECLARE @password NVARCHAR(255) = 'jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=';

-- Actualizar todas las contrase�as
UPDATE Usuarios
SET Password = @password
WHERE Email IN (
    'supervisor@pepsico.cl',
    'juan.perez@pepsico.cl',
    'pedro.gonzalez@pepsico.cl',
    'carlos.rojas@pepsico.cl',
    'luis.munoz@pepsico.cl'
);

PRINT '=================================================================';
PRINT 'Contrase�as actualizadas correctamente.';
PRINT 'Todos los usuarios ahora tienen la contrase�a: 123456';
PRINT '';
PRINT 'Hash SHA256: jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=';
PRINT '=================================================================';
GO

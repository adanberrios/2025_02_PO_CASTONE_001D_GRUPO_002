using Microsoft.EntityFrameworkCore;
using PepsicoChile.Models;

namespace PepsicoChile.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Vehiculo> Vehiculos { get; set; }
        public DbSet<IngresoTaller> IngresosTaller { get; set; }
        public DbSet<TareaTaller> TareasTaller { get; set; }
        public DbSet<Pausa> Pausas { get; set; }
        public DbSet<Documento> Documentos { get; set; }
        public DbSet<Repuesto> Repuestos { get; set; }
        public DbSet<MovimientoRepuesto> MovimientosRepuesto { get; set; }
        public DbSet<SolicitudRepuesto> SolicitudesRepuesto { get; set; }
        public DbSet<DocumentoVehiculo> DocumentosVehiculo { get; set; }
        public DbSet<Notificacion> Notificaciones { get; set; }
        public DbSet<AsignacionVehiculo> AsignacionesVehiculo { get; set; }
        public DbSet<ImagenIngreso> ImagenesIngreso { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configuraci�n de Usuario
            modelBuilder.Entity<Usuario>(entity =>
              {
                  entity.ToTable("Usuarios");
                  entity.HasKey(e => e.Id);
                  entity.Property(e => e.Nombre).IsRequired().HasMaxLength(100);
                  entity.Property(e => e.Apellido).IsRequired().HasMaxLength(100);
                  entity.Property(e => e.Email).IsRequired().HasMaxLength(200);
                  entity.Property(e => e.Telefono).HasMaxLength(20);
                  entity.Property(e => e.Rol).IsRequired().HasMaxLength(50);
                  entity.Property(e => e.Rut).IsRequired().HasMaxLength(20);
                  entity.Property(e => e.Password).IsRequired().HasMaxLength(255);

                  // �ndice �nico para RUT y Email
                  entity.HasIndex(e => e.Rut).IsUnique();
                  entity.HasIndex(e => e.Email).IsUnique();
              });

            // Configuraci�n de Vehiculo
            modelBuilder.Entity<Vehiculo>(entity =>
            {
                  entity.ToTable("Vehiculos");
                  entity.HasKey(e => e.Id);
                  entity.Property(e => e.Patente).IsRequired().HasMaxLength(10);
                  entity.Property(e => e.Marca).IsRequired().HasMaxLength(50);
                  entity.Property(e => e.Modelo).IsRequired().HasMaxLength(50);
                  entity.Property(e => e.TipoVehiculo).IsRequired().HasMaxLength(50);
                  entity.Property(e => e.Estado).IsRequired().HasMaxLength(50);

                  entity.HasIndex(e => e.Patente).IsUnique();
            });

            // Configuraci�n de IngresoTaller
            modelBuilder.Entity<IngresoTaller>(entity =>
                  {
                      entity.ToTable("IngresosTaller");
                      entity.HasKey(e => e.Id);

                      entity.HasOne(e => e.Vehiculo)
                 .WithMany()
                   .HasForeignKey(e => e.VehiculoId)
         .OnDelete(DeleteBehavior.Restrict);

                      entity.HasOne(e => e.Chofer)
            .WithMany()
             .HasForeignKey(e => e.ChoferId)
        .OnDelete(DeleteBehavior.Restrict);

                      entity.HasOne(e => e.Supervisor)
                     .WithMany()
      .HasForeignKey(e => e.SupervisorId)
                  .OnDelete(DeleteBehavior.Restrict);
                  });

            // Configuraci�n de TareaTaller
            modelBuilder.Entity<TareaTaller>(entity =>
               {
                   entity.ToTable("TareasTaller");
                   entity.HasKey(e => e.Id);

                   entity.HasOne(e => e.IngresoTaller)
            .WithMany()
     .HasForeignKey(e => e.IngresoTallerId)
          .OnDelete(DeleteBehavior.Cascade);

                   entity.HasOne(e => e.MecanicoAsignado)
               .WithMany()
            .HasForeignKey(e => e.MecanicoAsignadoId)
          .OnDelete(DeleteBehavior.Restrict);
               });

            // Configuraci�n de Pausa
            modelBuilder.Entity<Pausa>(entity =>
                    {
                        entity.ToTable("Pausas");
                        entity.HasKey(e => e.Id);

                        entity.HasOne(e => e.IngresoTaller)
                  .WithMany()
                     .HasForeignKey(e => e.IngresoTallerId)
              .OnDelete(DeleteBehavior.Cascade);

                        entity.HasOne(e => e.UsuarioRegistro)
                 .WithMany()
               .HasForeignKey(e => e.UsuarioRegistroId)
             .OnDelete(DeleteBehavior.Restrict);
                    });

            // Configuraci�n de Documento
            modelBuilder.Entity<Documento>(entity =>
               {
                   entity.ToTable("Documentos");
                   entity.HasKey(e => e.Id);

                   entity.HasOne(e => e.IngresoTaller)
          .WithMany()
              .HasForeignKey(e => e.IngresoTallerId)
                   .OnDelete(DeleteBehavior.Cascade);

                   entity.HasOne(e => e.UsuarioSubida)
                        .WithMany()
                         .HasForeignKey(e => e.UsuarioSubidaId)
                   .OnDelete(DeleteBehavior.Restrict);
               });

            // Configuraci�n de Repuesto
            modelBuilder.Entity<Repuesto>(entity =>
             {
                 entity.ToTable("Repuestos");
                 entity.HasKey(e => e.Id);
                 
                 // �ndice �nico compuesto: Nombre + Proveedor
                 entity.HasIndex(e => new { e.Nombre, e.Proveedor })
                     .IsUnique()
                     .HasDatabaseName("IX_Repuestos_Nombre_Proveedor");
                 
                 entity.HasIndex(e => e.CodigoRepuesto);
                 entity.HasIndex(e => e.Categoria);
             });

            // Configuraci�n de MovimientoRepuesto
            modelBuilder.Entity<MovimientoRepuesto>(entity =>
            {
                entity.ToTable("MovimientosRepuesto");
                entity.HasKey(e => e.Id);

                entity.HasOne(e => e.Repuesto)
                    .WithMany()
                    .HasForeignKey(e => e.RepuestoId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Vehiculo)
                    .WithMany()
                    .HasForeignKey(e => e.VehiculoId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.TareaTaller)
                    .WithMany()
                    .HasForeignKey(e => e.TareaTallerId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Mecanico)
                    .WithMany()
                    .HasForeignKey(e => e.MecanicoId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.UsuarioRegistro)
                    .WithMany()
                    .HasForeignKey(e => e.UsuarioRegistroId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasIndex(e => e.FechaMovimiento);
                entity.HasIndex(e => e.TipoMovimiento);
            });

            // Configuraci�n de SolicitudRepuesto
            modelBuilder.Entity<SolicitudRepuesto>(entity =>
            {
                entity.ToTable("SolicitudesRepuesto");
                entity.HasKey(e => e.Id);

                entity.HasOne(e => e.TareaTaller)
                    .WithMany()
                    .HasForeignKey(e => e.TareaTallerId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.SolicitadoPor)
                    .WithMany()
                    .HasForeignKey(e => e.SolicitadoPorId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasIndex(e => e.Estado);
                entity.HasIndex(e => e.FechaSolicitud);
            });
        }
    }
}

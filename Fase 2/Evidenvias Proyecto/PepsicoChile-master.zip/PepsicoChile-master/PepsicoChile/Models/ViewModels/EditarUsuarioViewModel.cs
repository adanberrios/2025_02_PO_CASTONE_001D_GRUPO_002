using System.ComponentModel.DataAnnotations;

namespace PepsicoChile.Models.ViewModels
{
    public class EditarUsuarioViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        [Display(Name = "Nombre")]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "El apellido es requerido")]
        [Display(Name = "Apellido")]
        public string Apellido { get; set; } = string.Empty;

        [Required(ErrorMessage = "El RUT es requerido")]
        [Display(Name = "RUT")]
        public string Rut { get; set; } = string.Empty;

        [Required(ErrorMessage = "El email es requerido")]
        [EmailAddress(ErrorMessage = "Email no v�lido")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Phone(ErrorMessage = "Tel�fono no v�lido")]
        [Display(Name = "Tel�fono")]
        public string? Telefono { get; set; }

        [Required(ErrorMessage = "El rol es requerido")]
        [Display(Name = "Rol")]
        public string Rol { get; set; } = string.Empty;

        [Display(Name = "Usuario Activo")]
        public bool Activo { get; set; }

        [StringLength(100, MinimumLength = 6, ErrorMessage = "La contrase�a debe tener al menos 6 caracteres")]
        [DataType(DataType.Password)]
        [Display(Name = "Nueva Contrase�a (dejar vac�o para no cambiar)")]
        public string? NuevaPassword { get; set; }

        [DataType(DataType.Password)]
        [Compare("NuevaPassword", ErrorMessage = "Las contrase�as no coinciden")]
        [Display(Name = "Confirmar Nueva Contrase�a")]
        public string? ConfirmarPassword { get; set; }
    }
}

using System.ComponentModel.DataAnnotations;

namespace PepsicoChile.Models.ViewModels
{
     public class RegisterViewModel
     {
        [Required(ErrorMessage = "El nombre es requerido")]
        [Display(Name = "Nombre")]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "El apellido es requerido")]
        [Display(Name = "Apellido")]
        public string Apellido { get; set; } = string.Empty;

        [Required(ErrorMessage = "El RUT es requerido")]
        [Display(Name = "RUT")]
        public string Rut { get; set; } = string.Empty;

        [Required(ErrorMessage = "El email es requerido")]
        [EmailAddress(ErrorMessage = "Email no v�lido")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Phone(ErrorMessage = "Tel�fono no v�lido")]
        [Display(Name = "Tel�fono")]
        public string? Telefono { get; set; }

        [Required(ErrorMessage = "El rol es requerido")]
        [Display(Name = "Rol")]
        public string Rol { get; set; } = string.Empty;

        [Required(ErrorMessage = "La contrase�a es requerida")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "La contrase�a debe tener al menos 6 caracteres")]
        [DataType(DataType.Password)]
        [Display(Name = "Contrase�a")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe confirmar la contrase�a")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Las contrase�as no coinciden")]
        [Display(Name = "Confirmar Contrase�a")]
        public string ConfirmPassword { get; set; } = string.Empty;
     }
}

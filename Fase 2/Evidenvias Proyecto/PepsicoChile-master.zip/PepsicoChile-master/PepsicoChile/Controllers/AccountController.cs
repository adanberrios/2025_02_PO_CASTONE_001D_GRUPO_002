﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PepsicoChile.Data;
using PepsicoChile.Models.ViewModels;
using PepsicoChile.Filters;
using System.Security.Cryptography;
using System.Text;

namespace PepsicoChile.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (ModelState.IsValid)
            {
                try
                {
                    // Log para debug
                    Console.WriteLine($"Intento de login: {model.Email}");

                    var hashedPassword = HashPassword(model.Password);
                    Console.WriteLine($"Password hasheado: {hashedPassword.Substring(0, 20)}...");

                    var usuario = await _context.Usuarios
                                .AsNoTracking() // Mejora de rendimiento
                                .FirstOrDefaultAsync(u => u.Email == model.Email
                                 && u.Password == hashedPassword
                       && u.Activo);

                    if (usuario != null)
                    {
                        Console.WriteLine($"Usuario encontrado: {usuario.Nombre} - Rol: {usuario.Rol}");

                        // Configurar sesión
                        HttpContext.Session.SetInt32("UsuarioId", usuario.Id);
                        HttpContext.Session.SetString("UsuarioNombre", usuario.Nombre + " " + usuario.Apellido);
                        HttpContext.Session.SetString("UsuarioRol", usuario.Rol);
                        HttpContext.Session.SetString("UsuarioEmail", usuario.Email);

                        // Guardar cambios de sesión
                        await HttpContext.Session.CommitAsync();

                        TempData["Mensaje"] = $"¡Bienvenido {usuario.Nombre}!";

                        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                        {
                            Console.WriteLine($"Redirigiendo a: {returnUrl}");
                            return Redirect(returnUrl);
                        }
                        else
                        {
                            Console.WriteLine("Redirigiendo a Home/Index");
                            return RedirectToAction("Index", "Home");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"No se encontró usuario con email: {model.Email}");
                        ModelState.AddModelError(string.Empty, "Email o contraseña incorrectos, o usuario inactivo");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"ERROR COMPLETO en Login:");
                    Console.WriteLine($"Mensaje: {ex.Message}");
                    Console.WriteLine($"StackTrace: {ex.StackTrace}");
                    Console.WriteLine($"InnerException: {ex.InnerException?.Message}");

                    ModelState.AddModelError(string.Empty, "Error al conectar con la base de datos. Por favor, intente nuevamente.");

                    // Si es un error de conexión, mostrar mensaje específico
                    if (ex.InnerException?.Message.Contains("network") == true ||
                   ex.InnerException?.Message.Contains("connection") == true)
                    {
                        ModelState.AddModelError(string.Empty, "No se puede conectar a la base de datos. Verifique la conexión.");
                    }
                }
            }
            else
            {
                Console.WriteLine("ModelState inválido:");
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine($"  - {error.ErrorMessage}");
                }
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["Mensaje"] = "Sesión cerrada exitosamente";
            return RedirectToAction("Login");
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }

        [HttpGet]
        public IActionResult TestHash(string password = "123456")
        {
            var hash = HashPassword(password);
            var expectedHash = "jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI=";

            return Json(new
            {
                Password = password,
                GeneratedHash = hash,
                ExpectedHash = expectedHash,
                Match = hash == expectedHash,
                Message = hash == expectedHash ? "✓ Hash correcto" : "✗ Hash incorrecto"
            });
        }

        [HttpGet]
        public async Task<IActionResult> TestUsers()
        {
            var usuarios = await _context.Usuarios
      .Select(u => new
      {
          u.Id,
          u.Email,
          u.Nombre,
          u.Apellido,
          u.Rol,
          u.Activo,
          PasswordHash = u.Password.Substring(0, 20) + "..." // Solo mostrar parte del hash
      })
    .ToListAsync();

            return Json(new
            {
                TotalUsuarios = usuarios.Count,
                Usuarios = usuarios,
                HashEsperado = "jZae727K08KaOmKSgOaGzww/XVqGr/PKEgIMkjrcbJI="
            });
        }

        // SOLO ADMINISTRADOR
        [HttpGet]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var existeEmail = await _context.Usuarios.AnyAsync(u => u.Email == model.Email);
                var existeRut = await _context.Usuarios.AnyAsync(u => u.Rut == model.Rut);

                if (existeEmail)
                {
                    ModelState.AddModelError("Email", "Este email ya está registrado");
                    return View(model);
                }

                if (existeRut)
                {
                    ModelState.AddModelError("Rut", "Este RUT ya está registrado");
                    return View(model);
                }

                var usuario = new Models.Usuario
                {
                    Nombre = model.Nombre,
                    Apellido = model.Apellido,
                    Email = model.Email,
                    Telefono = model.Telefono ?? string.Empty,
                    Rut = model.Rut,
                    Rol = model.Rol,
                    Password = HashPassword(model.Password),
                    Activo = true
                };

                _context.Usuarios.Add(usuario);
                await _context.SaveChangesAsync();

                TempData["Mensaje"] = "Usuario registrado exitosamente";
                return RedirectToAction("ListarUsuarios");
            }

            return View(model);
        }

        [HttpGet]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> ListarUsuarios()
        {
            var usuarios = await _context.Usuarios
               .OrderByDescending(u => u.Id)
            .ToListAsync();

            return View(usuarios);
        }

        [HttpGet]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> Editar(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            
            if (usuario == null)
            {
                TempData["Error"] = "Usuario no encontrado";
                return RedirectToAction("ListarUsuarios");
            }

            var model = new EditarUsuarioViewModel
            {
                Id = usuario.Id,
                Nombre = usuario.Nombre,
                Apellido = usuario.Apellido,
                Email = usuario.Email,
                Telefono = usuario.Telefono,
                Rut = usuario.Rut,
                Rol = usuario.Rol,
                Activo = usuario.Activo
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> Editar(EditarUsuarioViewModel model)
        {
            if (ModelState.IsValid)
            {
                var usuario = await _context.Usuarios.FindAsync(model.Id);
                
                if (usuario == null)
                {
                    TempData["Error"] = "Usuario no encontrado";
                    return RedirectToAction("ListarUsuarios");
                }

                // Verificar si el email ya existe (excepto el actual)
                var existeEmail = await _context.Usuarios
                    .AnyAsync(u => u.Email == model.Email && u.Id != model.Id);
                
                if (existeEmail)
                {
                    ModelState.AddModelError("Email", "Este email ya está en uso por otro usuario");
                    return View(model);
                }

                // Verificar si el RUT ya existe (excepto el actual)
                var existeRut = await _context.Usuarios
                    .AnyAsync(u => u.Rut == model.Rut && u.Id != model.Id);
                
                if (existeRut)
                {
                    ModelState.AddModelError("Rut", "Este RUT ya está en uso por otro usuario");
                    return View(model);
                }

                // Actualizar datos
                usuario.Nombre = model.Nombre;
                usuario.Apellido = model.Apellido;
                usuario.Email = model.Email;
                usuario.Telefono = model.Telefono ?? string.Empty;
                usuario.Rut = model.Rut;
                usuario.Rol = model.Rol;
                usuario.Activo = model.Activo;

                // Si se proporciona nueva contraseña, actualizarla
                if (!string.IsNullOrWhiteSpace(model.NuevaPassword))
                {
                    usuario.Password = HashPassword(model.NuevaPassword);
                }

                _context.Update(usuario);
                await _context.SaveChangesAsync();

                TempData["Mensaje"] = "Usuario actualizado exitosamente";
                return RedirectToAction("ListarUsuarios");
            }

            return View(model);
        }

        [HttpGet]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> Detalle(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            
            if (usuario == null)
            {
                TempData["Error"] = "Usuario no encontrado";
                return RedirectToAction("ListarUsuarios");
            }

            return View(usuario);
        }

        [HttpPost]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> CambiarPassword(int id, string nuevaPassword)
        {
            if (string.IsNullOrWhiteSpace(nuevaPassword))
            {
                TempData["Error"] = "La contraseña no puede estar vacía";
                return RedirectToAction("Editar", new { id });
            }

            var usuario = await _context.Usuarios.FindAsync(id);
            
            if (usuario == null)
            {
                TempData["Error"] = "Usuario no encontrado";
                return RedirectToAction("ListarUsuarios");
            }

            usuario.Password = HashPassword(nuevaPassword);
            await _context.SaveChangesAsync();

            TempData["Mensaje"] = "Contraseña actualizada exitosamente";
            return RedirectToAction("Editar", new { id });
        }

        [HttpPost]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> ActivarDesactivar(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario != null && usuario.Rol != "Administrador")
            {
                usuario.Activo = !usuario.Activo;
                await _context.SaveChangesAsync();
                TempData["Mensaje"] = $"Usuario {(usuario.Activo ? "activado" : "desactivado")} correctamente";
            }

            return RedirectToAction("ListarUsuarios");
        }

        [HttpPost]
        [AuthorizeSession]
        [AuthorizeRole("Administrador")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            
            if (usuario == null)
            {
                TempData["Error"] = "Usuario no encontrado";
                return RedirectToAction("ListarUsuarios");
            }

            // No permitir eliminar administradores
            if (usuario.Rol == "Administrador")
            {
                TempData["Error"] = "No se puede eliminar un usuario administrador";
                return RedirectToAction("ListarUsuarios");
            }

            // Verificar si tiene registros relacionados
            var tieneIngresos = await _context.IngresosTaller
                .AnyAsync(i => i.ChoferId == id || i.MecanicoAsignadoId == id || i.SupervisorId == id);

            var tieneTareas = await _context.TareasTaller
                .AnyAsync(t => t.MecanicoAsignadoId == id);

            if (tieneIngresos || tieneTareas)
            {
                TempData["Error"] = "No se puede eliminar el usuario porque tiene registros asociados. Desactívelo en su lugar.";
                return RedirectToAction("ListarUsuarios");
            }

            _context.Usuarios.Remove(usuario);
            await _context.SaveChangesAsync();

            TempData["Mensaje"] = "Usuario eliminado exitosamente";
            return RedirectToAction("ListarUsuarios");
        }
    }
}
